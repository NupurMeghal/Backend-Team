package com.tasteofindia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminOmApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminOmApplication.class, args);
	}

}

