package com.tasteofindia.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tasteofindia.admin.entity.FoodItem;
import com.tasteofindia.admin.repository.FoodItemRepository;

@Service
public class FoodItemService {

    @Autowired
    private FoodItemRepository foodItemRepository;

    public List<FoodItem> getAllFoodItems() {
        return foodItemRepository.findAll();
    }

    public FoodItem getFoodItemById(Long id) {
        return foodItemRepository.findById(id).orElse(null);
    }

    public FoodItem addFoodItem(FoodItem foodItem) {
        return foodItemRepository.save(foodItem);
    }

    public FoodItem updateFoodItem(Long id, FoodItem foodItem) {
        return foodItemRepository.findById(id).map(existingItem -> {
            existingItem.setName(foodItem.getName());
            existingItem.setDescription(foodItem.getDescription());
            existingItem.setPrice(foodItem.getPrice());
            existingItem.setCategory(foodItem.getCategory());
            return foodItemRepository.save(existingItem);
        }).orElse(null);
    }

    public void deleteFoodItem(Long id) {
        foodItemRepository.deleteById(id);
    }
}
