package com.tasteofindia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasteOfIndiaAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
