package com.test.backendtestofindia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendtestofindiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
