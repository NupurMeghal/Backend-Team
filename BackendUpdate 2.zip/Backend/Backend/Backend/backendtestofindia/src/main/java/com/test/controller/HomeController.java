package com.test.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.test.Entities.User;
import com.test.dao.UserRepository;

import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
    
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/Signup")
    public String signup(Model model) {
        model.addAttribute("title", "Signup");
        model.addAttribute("user", new User());
        return "Signup";
    }

    @PostMapping("/do_register")
    public String registerUser(@ModelAttribute("user") User user, Model model) {
       
        user.setPasswordHash(user.getPasswordHash());
        userRepository.save(user);
        model.addAttribute("message", "User registered successfully!");
        return "redirect:/Login";
    }

    @GetMapping("/Login")
    public String login(Model model) {
        model.addAttribute("title", "Login");
        return "Login";
    }

    @PostMapping("/do_login")
    public String doLogin(@RequestParam("username") String username, 
                          @RequestParam("password") String password, 
                          Model model) {
    
        
        Optional<User> userOptional = userRepository.findByUsernameAndPasswordHash(username, password);
    
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            model.addAttribute("user", user);
    
           
            switch (user.getRole().name()) {
                case "ADMIN":
                    return "redirect:/admin/home";
                case "CUSTOMER":
                    return "redirect:/customer/home";
                case "VENDOR":
                    return "redirect:/vendor/home";
                case "SUPERADMIN":
                    return "redirect:/superadmin/home";
                default:
                    return "redirect:/login?error=role";
            }
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "Login";
        }      
    }
    @GetMapping("/Logout")
    public String logout(HttpSession session) {
        session.invalidate(); 
        return "redirect:/Login?logout=true";
    }

    
}    